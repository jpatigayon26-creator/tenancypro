-- ============================================================
-- TenancyPro — Supabase Setup
-- Run this entire file in: Supabase Dashboard → SQL Editor
-- ============================================================

-- 1. Contracts table
--    Each row stores one contract as JSONB, linked to the owner.
-- ------------------------------------------------------------
create table if not exists contracts (
  id          text        primary key,
  user_id     uuid        not null references auth.users(id) on delete cascade,
  data        jsonb       not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Index for fast per-user queries
create index if not exists contracts_user_id_idx on contracts(user_id);
create index if not exists contracts_updated_at_idx on contracts(updated_at desc);

-- 2. Row Level Security — users only see their own contracts
-- ------------------------------------------------------------
alter table contracts enable row level security;

-- Drop existing policies if re-running
drop policy if exists "Users can read own contracts"   on contracts;
drop policy if exists "Users can insert own contracts" on contracts;
drop policy if exists "Users can update own contracts" on contracts;
drop policy if exists "Users can delete own contracts" on contracts;

create policy "Users can read own contracts"
  on contracts for select
  using ( auth.uid() = user_id );

create policy "Users can insert own contracts"
  on contracts for insert
  with check ( auth.uid() = user_id );

create policy "Users can update own contracts"
  on contracts for update
  using ( auth.uid() = user_id )
  with check ( auth.uid() = user_id );

create policy "Users can delete own contracts"
  on contracts for delete
  using ( auth.uid() = user_id );

-- 3. Auto-update updated_at on every row change
-- ------------------------------------------------------------
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists contracts_updated_at on contracts;
create trigger contracts_updated_at
  before update on contracts
  for each row execute function update_updated_at();

-- ============================================================
-- Done! Your contracts table is ready.
-- ============================================================
