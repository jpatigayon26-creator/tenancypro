import { useState } from 'react'
import { supabase } from './supabase.js'

const G = {
  navy: '#08182e', navyLight: '#0e2240',
  gold: '#C9A84C', goldDark: '#a8843d',
  text: '#e8edf5', textMuted: '#7a90a8',
  border: 'rgba(255,255,255,0.07)', borderGold: 'rgba(201,168,76,0.25)',
  red: '#ef4444',
}

const inp = {
  width: '100%', padding: '.65rem .875rem',
  background: 'rgba(255,255,255,.05)', border: `1px solid ${G.border}`,
  borderRadius: '8px', color: G.text, fontSize: '.9rem',
  outline: 'none', transition: 'border-color .2s',
}

export default function Auth() {
  const [mode, setMode]       = useState('login')   // 'login' | 'signup' | 'reset'
  const [email, setEmail]     = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [msg, setMsg]         = useState(null)       // { type: 'error'|'ok', text }

  const handle = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMsg(null)

    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error

      } else if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        setMsg({ type: 'ok', text: 'Account created! Check your email to confirm, then log in.' })
        setMode('login')

      } else if (mode === 'reset') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin,
        })
        if (error) throw error
        setMsg({ type: 'ok', text: 'Password reset link sent — check your email.' })
        setMode('login')
      }
    } catch (err) {
      setMsg({ type: 'error', text: err.message })
    } finally {
      setLoading(false)
    }
  }

  const titles = { login: 'Sign in', signup: 'Create account', reset: 'Reset password' }

  return (
    <div style={{ minHeight: '100vh', background: G.navy, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap'); *{box-sizing:border-box;margin:0;padding:0} input:focus{border-color:rgba(201,168,76,.5)!important}`}</style>

      <div style={{ width: '100%', maxWidth: '400px' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{ width: '52px', height: '52px', borderRadius: '12px', background: `linear-gradient(135deg,${G.gold},${G.goldDark})`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.6rem', marginBottom: '.875rem' }}>🏢</div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.6rem', fontWeight: '700', color: G.text }}>TenancyPro</div>
          <div style={{ fontSize: '.65rem', color: G.gold, letterSpacing: '.12em', textTransform: 'uppercase', marginTop: '.25rem' }}>Dubai Land Department · RERA Regulated</div>
        </div>

        {/* Card */}
        <div style={{ background: G.navyLight, borderRadius: '16px', border: `1px solid ${G.borderGold}`, padding: '2rem', boxShadow: '0 24px 60px rgba(0,0,0,.4)' }}>
          <h2 style={{ color: G.text, fontSize: '1.1rem', fontWeight: '600', marginBottom: '1.5rem' }}>{titles[mode]}</h2>

          {msg && (
            <div style={{ padding: '.75rem 1rem', borderRadius: '8px', marginBottom: '1.25rem', fontSize: '.82rem', background: msg.type === 'ok' ? 'rgba(34,197,94,.1)' : 'rgba(239,68,68,.1)', border: `1px solid ${msg.type === 'ok' ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)'}`, color: msg.type === 'ok' ? '#22c55e' : G.red }}>
              {msg.text}
            </div>
          )}

          <form onSubmit={handle}>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', color: G.textMuted, fontSize: '.7rem', fontWeight: '600', letterSpacing: '.09em', textTransform: 'uppercase', marginBottom: '.35rem' }}>Email</label>
              <input style={inp} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@email.com" required autoComplete="email" />
            </div>

            {mode !== 'reset' && (
              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{ display: 'block', color: G.textMuted, fontSize: '.7rem', fontWeight: '600', letterSpacing: '.09em', textTransform: 'uppercase', marginBottom: '.35rem' }}>Password</label>
                <input style={inp} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required={mode !== 'reset'} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} minLength={6} />
              </div>
            )}

            <button type="submit" disabled={loading} style={{ width: '100%', padding: '.7rem', borderRadius: '8px', border: 'none', background: `linear-gradient(135deg,${G.gold},${G.goldDark})`, color: '#08182e', fontWeight: '700', fontSize: '.9rem', cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? .7 : 1, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              {loading ? 'Please wait…' : titles[mode]}
            </button>
          </form>

          {/* Mode switchers */}
          <div style={{ marginTop: '1.25rem', display: 'flex', flexDirection: 'column', gap: '.5rem', alignItems: 'center' }}>
            {mode === 'login' && <>
              <button onClick={() => { setMode('signup'); setMsg(null); }} style={{ background: 'none', border: 'none', color: G.textMuted, cursor: 'pointer', fontSize: '.82rem' }}>Don't have an account? <span style={{ color: G.gold }}>Sign up</span></button>
              <button onClick={() => { setMode('reset'); setMsg(null); }} style={{ background: 'none', border: 'none', color: G.textMuted, cursor: 'pointer', fontSize: '.78rem' }}>Forgot password?</button>
            </>}
            {mode !== 'login' && (
              <button onClick={() => { setMode('login'); setMsg(null); }} style={{ background: 'none', border: 'none', color: G.textMuted, cursor: 'pointer', fontSize: '.82rem' }}>← Back to sign in</button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
